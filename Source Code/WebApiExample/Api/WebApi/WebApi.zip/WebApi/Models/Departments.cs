﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class Departments
    {
       
        public int? departmentsID { get; set; }
       
        public string departmentsName { get; set; }
    }
}
